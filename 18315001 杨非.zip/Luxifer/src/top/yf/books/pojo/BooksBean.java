package top.yf.books.pojo;


import java.util.List;

public class BooksBean {
	private List<Book> rows;

	public List<Book> getRows() {
		return rows;
	}

	public void setRows(List<Book> rows) {
		this.rows = rows;
	}
	
	

}