package top.yf.books.pojo;

public class Book {
	private int Bid;
	private String Bname;
	private int Bnumber;
	public int getBid() {
		return Bid;
	}
	public void setBid(int bid) {
		Bid = bid;
	}
	public String getBname() {
		return Bname;
	}
	public void setBname(String bname) {
		Bname = bname;
	}
	public int getBnumber() {
		return Bnumber;
	}
	public void setBnumber(int bnumber) {
		Bnumber = bnumber;
	}
	

}